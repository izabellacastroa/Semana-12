﻿using System;

class Program
{
    static void Main()
    {
        int[] numeros = new int[10];

        Console.WriteLine("Ingresar 10 números enteros:");

        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Número {i + 1}: ");
            numeros[i] = Convert.ToInt32(Console.ReadLine());
        }

        int suma = 0;
        foreach (int numero in numeros)
        {
            suma += numero;
        }

        double promedio = (double)suma / numeros.Length;

        Console.WriteLine($"La sumatoria de todos los números es: {suma}");
        Console.WriteLine($"El promedio de todos los números es: {promedio}");
    }
}

