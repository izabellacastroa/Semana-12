﻿using System;

class Program
{
    static void Main()
    {
        string[] nombres = new string[10];

        Console.WriteLine("Ingresar 10 nombres con apellidos:");

        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Nombre {i + 1}: ");
            nombres[i] = Console.ReadLine();
        }

        Array.Sort(nombres);

        Console.WriteLine("Lista en orden alfabético:");

        foreach (string nombre in nombres)
        {
            Console.WriteLine(nombre);
        }
    }
}

